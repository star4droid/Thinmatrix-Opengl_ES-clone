package com.my.opengl; 
import com.my.opengl.ToolBox.Vector;

public class Camera {
private Vector position = new Vector(0,0,0);
//private Vector rotation = new Vector(0,0,0);

private float pitch=0,yaw=0,roll=0;

public Camera(){

}

public void setPostion(float x,float y,float z){
position = new Vector(x,y,z);
}
public void move(){
//pitch+=33.0f;
position.z+=MainActivity.z;
position.y+=MainActivity.y;
position.x+=MainActivity.x;
}

public Vector getPosition(){
return position;
}

public float getPitch(){
return pitch;
}

public float getYaw(){
return yaw;
}

public float getRoll(){
return roll;
}

} 