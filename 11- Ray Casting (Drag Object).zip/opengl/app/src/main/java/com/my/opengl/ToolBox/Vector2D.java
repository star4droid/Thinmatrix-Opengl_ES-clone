package com.my.opengl.ToolBox;

public class Vector2D {
public float x=0,y=0;
public Vector2D(float x,float y){
this.x=x;
this.y=y;
}
}