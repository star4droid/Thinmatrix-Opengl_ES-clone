package com.my.opengl.Shaders;
//import android.opengl.GLES30;
import com.my.opengl.Camera;
import com.my.opengl.ToolBox.Maths;
import com.my.opengl.ToolBox.ESTransform;
import com.my.opengl.Entities.Light;
import com.my.opengl.TextureLoader;
//import com.my.opengl.ToolBox.Vector;

public class staticShader extends ShaderProgram {
	public static String log="Hello";
	int transformation;
	int projection;
	int viewMatrix;
	int lightPos;
	int lightColor;
	int reflectivity;
	int skyColour;
	int textureDensity;
	int shineDampage;
	public staticShader(android.content.Context ctx){
	super("vertexShader.txt","fragmentShader.txt",ctx);
	log="Nothing...";
	}
	
	@Override
	protected void bindAttributes(){
	super.bindAttributes(0,"position");
	super.bindAttributes(1,"textureCoords");
	super.bindAttributes(2,"normal");
	}
	
	@Override
	protected void getAllUniformLocation(){
	transformation = super.getUniformLocation("transformation");
	TextureLoader.checkGLError("Render","failed to get transformation Error: ");
	projection = super.getUniformLocation("projection");
	TextureLoader.checkGLError("Render","failed to get projection Error: ");
	viewMatrix = super.getUniformLocation("viewMatrix");
	TextureLoader.checkGLError("Render","failed to get viewMatrix Error: ");
	
	lightColor = super.getUniformLocation("lightColor");
	TextureLoader.checkGLError("Render","failed to get lightColor Error: ");
	lightPos = super.getUniformLocation("lightPos");
	skyColour = super.getUniformLocation("skyColour");
	TextureLoader.checkGLError("Render","failed to get lightPos Error: ");
	
	shineDampage = super.getUniformLocation("shineDampage");
	
	textureDensity = super.getUniformLocation("textureDensity");
	TextureLoader.checkGLError("Render","failed to get shineDampage Error: ");
	reflectivity = super.getUniformLocation("reflectivity");
	TextureLoader.checkGLError("Render","failed to get reflectivity Error: ");
	}
	
	public void loadShineVariables(float shin,float reflect){
	super.loadFloat(shineDampage,shin);
	super.loadFloat(reflectivity,reflect);
	}
	
	public void loadSkyColour(float r,float g,float b){
	//super.loadVector(skyColour,new Vector(r,g,b));
	}

	public void loadTextureDensity(float d){
	super.loadFloat(textureDensity,d);
	}

	public void loadLight(Light light){
	super.loadVector(lightPos,light.getPosition());
	super.loadVector(lightColor,light.getColor());
	}
	
	public void loadViewMatrix(Camera camera){
	ESTransform matrix=Maths.createViewMatrix(camera);
	super.loadMatrix(viewMatrix,matrix);
	}
	
	public void loadTransformationMatrix(ESTransform matrix){
	super.loadMatrix(transformation,matrix);
	}
	
	public void loadProjectionMatrix(ESTransform matrix){
	super.loadMatrix(projection,matrix);
	}
}
