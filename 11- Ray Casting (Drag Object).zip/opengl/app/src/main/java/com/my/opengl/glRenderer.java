package com.my.opengl;

import android.opengl.GLES10;
//import android.opengl.GLES20;
import android.opengl.GLES30;
import com.my.opengl.Models.RawModel;
import com.my.opengl.Models.TextureModel;
//import com.my.opengl.Entities.Entity;
import javax.microedition.khronos.egl.EGLConfig;
import com.my.opengl.Shaders.staticShader;
import javax.microedition.khronos.opengles.GL10;
import android.opengl.GLSurfaceView;
import com.my.opengl.Entities.Entity;
import com.my.opengl.Entities.Light;
import com.my.opengl.ToolBox.Vector;
import Terrains.Terrain;
import com.my.opengl.ToolBox.Maths;
import com.my.opengl.ToolBox.Ray.Ray;
import com.my.opengl.ToolBox.RayPicker;
import com.my.opengl.ToolBox.Maths;
import java.util.ArrayList;

public class glRenderer extends android.opengl.GLSurfaceView  implements GLSurfaceView.Renderer {
	ModelTexture texture;
	ModelTexture TreeTexture;
	Entity entity;
	Entity entity2;
	ArrayList<Entity> entities = new ArrayList<>();
	Entity sky;
	RayPicker _ray;
	Entity Tree;
	Terrain terrain;
	Ray ray;
	long time=0;
	long Dtime=0;
	Terrain terrain2;
	float fFrames=60;
	MasterRenderer master;
	Light light=new Light(new Vector(0,0,-1),new Vector(0,1,0.0f));
	Camera camera = new Camera();
	TextureModel textureModel;
	TextureModel textureModel2;
	TextureModel TreetextureModel;
	
	public static android.widget.TextView activity;
	public glRenderer(android.content.Context ctx){
	super(ctx);
	setEGLConfigChooser(true);
	setEGLContextClientVersion(3);
	setRenderer(this);
	}
	public static android.widget.TextView debug=null;
	public RawModel model;
	public RawModel TreeModel;
	staticShader shader;
	Loader loader= new Loader();
	int mWidth=300,mHeight=300,frames=1;
	public void onSurfaceChanged ( GL10 gl, int width, int height )
   {
      mWidth = width;
      mHeight = height;
   }
   
     public void onDrawFrame ( GL10 gl)
   {
   frames++;
   GLES30.glViewport ( 0, 0, mWidth, mHeight );
   TextureLoader.checkGLError("Render","Render before master, Error: ");
   GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
	
	Tree.increaseRotation(0,30,30);
	//entity.increasePosition(0,0,0.035f);
	light.getPosition().x = camera.getPosition().x;
	light.getPosition().z = camera.getPosition().z+3;
	light.getPosition().y = camera.getPosition().y;
	camera.move();
	sky.setPosition(camera.getPosition());
	for(Entity entity:entities){
	entity.increaseRotation(0,30,30);
   master.processEntity(entity);
   }
   master.processTerrain(terrain);
   Dtime = System.currentTimeMillis();
   boolean b = Math.abs(System.currentTimeMillis()-time)>=1000;
   new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
				@Override
				public void run() {
				if(ray==null) return;
   activity.setText("fames: "+fFrames+",ray X: "+(float)(ray.P0[0])+" , ray Y : "+(float)(ray.P0[1]));
   	}
		});
   if(b){
   time = Dtime;
   fFrames=frames;
		frames=1;
		}
   //failed to load, idk why
   master.processEntity(Tree);
   //master.processEntity(sky);
   master.processTerrain(terrain2);
   //master.processEntity(entity2);
   if((MainActivity.TouchX !=-999)|true){
   if(ray==null){ray = new Ray(gl,mWidth,mHeight,MainActivity.TouchX,MainActivity.TouchY,master.getProjectionMatrix().get(),Maths.createViewMatrix(camera).get());} else {
   ray.update(gl,mWidth,mHeight,MainActivity.TouchX,MainActivity.TouchY,master.getProjectionMatrix().get(),Maths.createViewMatrix(camera).get());}
   //_ray.update();
   //MainActivity.TouchX=-999;
   }
   entity.setPosition(new Vector(camera.getPosition().x+ray.P0[0]*3,camera.getPosition().y + ray.P0[1]*3,camera.getPosition().z + ray.P0[2]-3));
   master.render(light,camera);
   TextureLoader.checkGLError("Model Render","model Error: ");
   }
   
   public void onSurfaceCreated ( GL10 gl, EGLConfig config )
   {
   MainActivity.x=0;
   MainActivity.y=0;
   MainActivity.z=0;
   gl.glShadeModel(GL10.GL_SMOOTH);
   camera.setPostion(0,3,0);
   master = new MasterRenderer(mWidth,mHeight,getContext());
   
   //loading .Obj
	model= ObjLoader.loadObj(getContext(),"test.obj",loader);
	TreeModel= ObjLoader.loadObj(getContext(),"tree.obj",loader);
	TextureLoader.checkGLError("Render","after loadToVao Error: ");
	TextureLoader.level=0;
	
	_ray = new RayPicker(camera,master.getProjectionMatrix(),mWidth,mHeight);
	
	//loading textures
	texture = new ModelTexture(loader.loadTexture(R.drawable.test,getContext()));
	ModelTexture SkyTexture = new ModelTexture(loader.loadTexture(R.drawable.sky,getContext()));
	TreeTexture = new ModelTexture(loader.loadTexture(R.drawable.white,getContext()));
	
	//test terrains
	terrain = new Terrain(0,-1,loader,new ModelTexture(loader.loadTexture(R.drawable.test,getContext())));
	terrain2 = new Terrain(1,-2,loader,new ModelTexture(loader.loadTexture(R.drawable.test,getContext())));
	TextureLoader.checkGLError("Render","after texture Load Error: ");
	
	//texture model for our models
	textureModel = new TextureModel(model,texture);
	
	//setting light options
	texture.setShineDampage(1);
	texture.setReflectivity(1);
	time=System.currentTimeMillis();
   TreeTexture.setShineDampage(10);
	TreeTexture.setReflectivity(1);
	
	//anthor texture model
   textureModel2 = new TextureModel(model,texture);
   TextureModel skyM = new TextureModel(model,SkyTexture);
   TextureModel TreeTextureModel = new TextureModel(TreeModel,TreeTexture);
   
   //set texture repeat count
	textureModel2.setDensity(40);
	//Entity(translation,rotation,scale)
	Tree = new Entity(TreeTextureModel,new Vector(-2,0,0),new Vector(0,0,0),new Vector(1,1,1));
	for (int i=0; i<100;i++){
   entity = new Entity(textureModel,new Vector(Maths.getRandom(0,20)-10,Maths.getRandom(0,20)-10,Maths.getRandom(0,10)-5),new Vector(Maths.getRandom(0,100),Maths.getRandom(0,100),Maths.getRandom(0,100)),1);
   entities.add(entity);
   }
   camera.setPosition(-5,4,9);
      sky = new Entity(skyM,new Vector(0,3,0),new Vector(0,0,0),-100);
   entity2 = new Entity(textureModel2,new Vector(0,3,-10),new Vector(0,0,0),new Vector(1,1,1));
   sky.depthTest = false;
   
   }
}
