package com.my.opengl;

import android.app.*;
import android.os.*;
import android.view.*;
import android.util.Log;
import android.widget.TextView;
import android.widget.LinearLayout;
import com.my.opengl.ToolBox.JoyStick;
//import com.my.opengl.ToolBox.RayPicker;
import android.opengl.GLSurfaceView;

public class MainActivity extends Activity 
{
	public static float x=0;
	public static float y=0;
	public static float z=0;
	public static float TouchX=0,TouchY=0;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TouchX = 0;
        TouchY = 0;
        //requestWindowFeature(Window.FEATURE_NO_TITLE);
//javax.microedition.khronos.opengles.GL.createCapabilities();
//here u go
glRenderer.activity=(TextView)(findViewById(R.id.txt));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                        WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //glRenderer.debug=textview1;
        LinearLayout joyLin =(LinearLayout) findViewById(R.id.joyLin);
        JoyStick joystick = new JoyStick(MainActivity.this);
		joyLin.addView(joystick);
		joystick.setListener(new JoyStick.JoyStickListener(){
		@Override
		public void onMove(JoyStick joystick , double angle567, double power321, int direction123){
		x =-1*(float)Math.cos(((double)joystick.getAngle()));
		z =-1*(float)Math.sin(((double)joystick.getAngle()));
		}
		@Override
		public void onTap() {}
		@Override
		public void onDoubleTap() {}
});
        GLSurfaceView view = new glRenderer(MainActivity.this);
        Log.v("Start","Ok");
        ((ViewGroup)(findViewById(R.id.lin))).addView(view);
          //just to make it appear always
        joyLin.setZ(100);
        findViewById(R.id.pads).setZ(101);
        findViewById(R.id.down).setOnTouchListener(new View.OnTouchListener(){
	@Override
	public boolean onTouch(View v, MotionEvent event){
		int ev = event.getAction();
		switch (ev) {
			case MotionEvent.ACTION_DOWN:
			
			y=-1;
			
			break;
			case MotionEvent.ACTION_UP:
			
			y=0;
			
			break;
		} return true;
	}
});

findViewById(R.id.lin).setOnTouchListener(new View.OnTouchListener(){
	@Override
	public boolean onTouch(View v, MotionEvent event){
		int ev = event.getAction();
		TouchX= event.getX();
		TouchY= event.getY();
		switch (ev) {
			case MotionEvent.ACTION_DOWN:
			
			
			break;
			case MotionEvent.ACTION_UP:
			
			
			break;
		} return true;
	}
});

findViewById(R.id.up).setOnTouchListener(new View.OnTouchListener(){
	@Override
	public boolean onTouch(View v, MotionEvent event){
		int ev = event.getAction();
		switch (ev) {
			case MotionEvent.ACTION_DOWN:
			
			y=1;
			
			break;
			case MotionEvent.ACTION_UP:
			
			y=0;
			
			break;
		} return true;
	}
});

    }
}
