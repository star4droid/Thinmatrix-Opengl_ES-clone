package com.my.opengl.ToolBox;
import com.my.opengl.Camera;
import android.renderscript.Matrix4f;
import com.my.opengl.MainActivity;
import android.opengl.Matrix;

public class RayPicker {

	private Vector current;
	private ESTransform projection;
	private ESTransform viewMatrix;
	private Matrix4f viewM;
	private Camera camera;
	float x=0,y=0,width=0,height=0;

	public RayPicker(Camera cam, ESTransform proj,float width,float height){
	this.camera = cam;
	this.projection = proj;
	update();
		}

	public Vector getCurrentRay(){
	return current;
	}

	private Vector calculateCurrentRay(float x,float y){
	Vector2D normal = getNurmalizeCoords(x,y);
	float[]  invertedP = new float[projection.get().length];
	android.opengl.Matrix.invertM(projection.get(),0,invertedP,0);
	float[] clip ={normal.x,normal.y,-1,1};
	Matrix4f inv=new Matrix4f(invertedP);
	//Matrix4f clipM = new Matrix4f(clip);
	//inv.multiply(clipM);
	Matrix.translateM(invertedP,0,normal.x,normal.y,-1);
	//==>inv.translate(normal.x,normal.y,-1);
	//float[] rayEye = inv.getArray();
	//rayEye = new float[]{rayEye[0],rayEye[1],-1,0};
	//Matrix4f eye = new Matrix4f(rayEye);
	float[] result= new float[invertedP.length];
	Matrix.multiplyMM(result,0,invertedP,0,viewMatrix.get(),0);
	//==>viewM.multiply(inv);
	//==>float[] result = viewM.getArray();
	final Vector2D normalizeC = getNurmalizeCoords(result[0],result[1]);
	//inv.translate(normal.x,normal.y,-1);
	//float[] result=inv.getArray();
	new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
				@Override
				public void run() {
				//com.my.opengl.glRenderer.activity.setText(result[0]+"");
				}
		});

	return new Vector(normalizeC.x,normalizeC.y,-1);
	}

	private Vector2D getNurmalizeCoords(float x,float y){
	float xx= (2*x)/width-1;
	float yy=(2*y)/height-1;
	return new Vector2D(xx,yy);
	}

	public void update(){
	this.viewMatrix = Maths.createViewMatrix(camera);
	this.viewM = new Matrix4f(viewMatrix.get());
	this.viewM.inverse();
	// viewMatrix = Maths.createViewMatrix(camera);
	current = calculateCurrentRay(MainActivity.TouchX,MainActivity.TouchY);
	}
}