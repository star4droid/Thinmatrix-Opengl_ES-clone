package com.my.opengl.Models;

public class RawModel {
    private int vaoID;
    private int vertexCount;
    public RawModel(int id,int vCount){
    this.vaoID=id;
    this.vertexCount=vCount;
    }
    
    public int getVaoID(){
    return this.vaoID;
    }
    public int getVertexCount(){
    return this.vertexCount;
    }
}
