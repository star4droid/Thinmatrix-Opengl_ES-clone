package com.my.opengl;

public class ModelTexture {
    private int ID;
    public ModelTexture(int id){
    this.ID=id;
    }
    
    public int getID(){
    return this.ID;
    }
}
