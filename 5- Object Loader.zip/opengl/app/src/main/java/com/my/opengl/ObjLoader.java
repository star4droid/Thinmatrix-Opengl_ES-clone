package com.my.opengl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;
import android.content.Context;
import com.my.opengl.Models.RawModel;

public class ObjLoader {

	public static RawModel loadObj(Context ctx,String fname,Loader loader){
	
	final float[] vertices;
        final float[] normals;
        final float[] textureCoords;
        final int[] indices;
        String objContents=readFromAsset(ctx,fname);
        Vector<Float> verticesTemp = new Vector<>();
        Vector<Float> normalsTemp = new Vector<>();
        Vector<Float> textureCoordsTemp = new Vector<>();
        Vector<String> facesTemp = new Vector<>();

        String[] lines = objContents.split("\n");
        for (String line : lines) {
            String[] parts = line.split(" ");
            switch (parts[0]) {
                case "v":
                    verticesTemp.add(Float.parseFloat(parts[1]));
                    verticesTemp.add(Float.parseFloat(parts[2]));
                    verticesTemp.add(Float.parseFloat(parts[3]));
                    break;
                case "vn":
                    normalsTemp.add(Float.parseFloat(parts[1]));
                    normalsTemp.add(Float.parseFloat(parts[2]));
                    normalsTemp.add(Float.parseFloat(parts[3]));
                    break;
                case "vt":
                    textureCoordsTemp.add(Float.parseFloat(parts[1]));
                    textureCoordsTemp.add(Float.parseFloat(parts[2]));
                    break;
                case "f":
                    facesTemp.add(parts[1]);
                    facesTemp.add(parts[2]);
                    facesTemp.add(parts[3]);
                    break;
            }
        }

        vertices = new float[verticesTemp.size()];
        normals = new float[normalsTemp.size()];
        textureCoords = new float[textureCoordsTemp.size()];
        indices = new int[facesTemp.size()];

        for (int i = 0, l = verticesTemp.size(); i < l; i++) {
            vertices[i] = verticesTemp.get(i);
        }
        for (int i = 0, l = normalsTemp.size(); i < l; i++) {
            normals[i] = normalsTemp.get(i);
        }
        for (int i = 0, l = textureCoordsTemp.size(); i < l; i++) {
            textureCoords[i] = textureCoordsTemp.get(i);
        }
        for (int i = 0, l = facesTemp.size(); i < l; i++) {
            //indices[i] = (short) (Short.parseShort(facesTemp.get(i).split("/")[0]) - 1);
            try {
            indices[i]= (byte) (Integer.parseInt(facesTemp.get(i).split("/")[0]) - 1);}catch(Exception ex){}
        }
        return loader.loadToVao(vertices,textureCoords,indices);
	}
	
	private static String readFromAsset( Context context, String fileName )
   {
      String result = null;

      if ( fileName == null )
      {
         return result;
      }

      // Read the shader file from assets
      InputStream is = null;
      byte [] buffer;

      try
      {
         is =  context.getAssets().open ( fileName );

         // Create a buffer that has the same size as the InputStream
         buffer = new byte[is.available()];

         // Read the text file as a stream, into the buffer
         is.read ( buffer );

         ByteArrayOutputStream os = new ByteArrayOutputStream();

         // Write this buffer to the output stream
         os.write ( buffer );

         // Close input and output streams
         os.close();
         is.close();

         result = os.toString();
      }
      catch ( IOException ioe )
      {
         is = null;
      }

      if ( is == null )
      {
         return result;
      }

      return result;
   }
} 