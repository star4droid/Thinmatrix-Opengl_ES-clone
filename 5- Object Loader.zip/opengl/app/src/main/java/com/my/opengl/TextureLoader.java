package com.my.opengl;
import android.opengl.GLUtils;
//import android.opengl.GLES10;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES20;
import android.opengl.GLES30;
import android.util.Log;
import javax.microedition.khronos.opengles.GL10;

public class TextureLoader {
public static int level=0;
public static int createTexture(android.content.Context contextRegf, int resource) 
 {
 Bitmap tempImage=null;
 tempImage =BitmapFactory.decodeResource(contextRegf.getResources(), resource);
return load(tempImage);
}

		public static int createTexture(android.content.Context contextRegf, String assets) 
 {
 Bitmap tempImage=null;
 try {
 tempImage =BitmapFactory.decodeStream(contextRegf.getAssets().open(assets));
} catch(java.io.IOException ex){}
return load(tempImage);
}


private static int load(Bitmap bitmap){
int[] textures= new int[1];
 checkGLError("Texture0","Texture0 Error: ");
 GLES20.glEnable(GLES20.GL_BLEND);
 checkGLError("Texture","Texture1 Error: ");
 GLES20.glGenTextures(1, textures, 0); 
 checkGLError("Texture","Texture2 Error: ");
 GLES20.glBindTexture(GL10.GL_TEXTURE_2D, textures[0]); 
 checkGLError("Texture","Texture3 Error: ");
 GLUtils.texImage2D(GL10.GL_TEXTURE_2D, level, bitmap, 0);
 level++; 
 checkGLError("Texture","Texture4 Error: ");
 checkGLError("Texture","Texture5 Error: ");
 GLES20.glTexParameterf( GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER, GL10.GL_LINEAR );
 checkGLError("Texture","Texture6 Error: ");
    GLES20.glTexParameterf( GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER, GL10.GL_LINEAR );
    checkGLError("Texture","Texture7 Error: ");

    GLES20.glTexParameterf( GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_WRAP_S, GL10.GL_REPEAT );
    checkGLError("Texture","Texture8 Error: ");
    GLES20.glTexParameterf( GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_WRAP_T, GL10.GL_REPEAT );
    checkGLError("Texture","Texture9 Error: ");
    GLES20.glBindTexture(GL10.GL_TEXTURE_2D,0);
    GLES20.glDisable(GLES20.GL_BLEND);
    checkGLError("Texture","Texture10 Error: ");
 return textures[0];
}

public static void checkGLError(String tag, String label) {
        int lastError = GLES20.GL_NO_ERROR;
        // Drain the queue of all errors.
        int error;
        while ((error = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
            Log.e(tag, label + ": glError " + error);
            lastError = error;
        }
        if (lastError != GLES20.GL_NO_ERROR) {
        staticShader.log=staticShader.log+"\n"+lastError;
            throw new RuntimeException(label + ": glError " + lastError);
            
        }
    }
    
}