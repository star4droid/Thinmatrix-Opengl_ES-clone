package com.my.opengl.ToolBox;
import com.my.opengl.ToolBox.Vector;
import com.my.opengl.Camera;
public class Maths {

	public static ESTransform createTransformationMatrix(Vector translation,Vector rotation,float scale){
	ESTransform matrix=new ESTransform();
	//Matrix.setIdentityM(matrix.get(),0);
	matrix.matrixLoadIdentity();
	matrix.translate(translation.x,translation.y,translation.z);
	matrix.rotate((float)Math.toRadians(rotation.x),1,0,0);
	matrix.rotate((float)Math.toRadians(rotation.y),0,1,0);
	matrix.rotate((float)Math.toRadians(rotation.z),0,0,1);
	matrix.scale(scale,scale,scale);
	return matrix;
	}
	
	public static ESTransform createViewMatrix(Camera camera){
	ESTransform vector= new ESTransform();
	Vector position = camera.getPosition();
	float pitch = camera.getPitch();
	float yaw = camera.getYaw();
	float roll = camera.getRoll();
	vector.matrixLoadIdentity();
		vector.rotate((float) Math.toRadians(pitch),1, 0, 0);
		vector.rotate((float) Math.toRadians(yaw),0, 1, 0);
		vector.rotate((float) Math.toRadians(roll),0,0,1);
		//Vector negativeCameraPos = new Vector(-position.x, -position.y, -position.z);
		vector.translate(-position.x,-position.y,-position.z);
		vector.scale(1,1,1);
		return vector;
	}
} 