package com.my.opengl.Models;
import com.my.opengl.ModelTexture;

public class TextureModel {
	private RawModel model;
	private ModelTexture texture;
	public TextureModel(RawModel raw,ModelTexture Texture){
	this.model=raw;
	this.texture=Texture;
	}
	
	public RawModel getRawModel(){
	return model;
	}
	
	public ModelTexture getTexture(){
	return texture;
	}
}
