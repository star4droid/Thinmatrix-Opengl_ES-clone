package com.my.opengl;
import android.content.Context;
import android.opengl.GLES30;
import android.opengl.GLES20;
import com.my.opengl.ToolBox.ESShader;
import com.my.opengl.ToolBox.Vector;
import com.my.opengl.ToolBox.ESTransform;

public abstract class ShaderProgram {
	public int id;
	public interface Binder {
	public void bind();
	}
	public ShaderProgram(String vertexShader,String fragmentShader,Context ctx){
	Binder binder= new Binder(){
	public void bind(){
	
	
	}
	};
	id=ESShader.loadProgramFromAsset(ctx,vertexShader,fragmentShader,binder);
	TextureLoader.checkGLError("Render","after load Error: ");
	bindAttributes();
	TextureLoader.checkGLError("Render","after bind Error: ");
	getAllUniformLocation();
	TextureLoader.checkGLError("Render","after getUniforms Error: ");
}
	
	protected void loadFloat(int location,float value){
	GLES30.glUniform1f(location,value);
	}
	
	protected void loadBoolean(int location,boolean value){
	int toLoad=0;
	if(value) toLoad=1;
	GLES30.glUniform1f(location,toLoad);
	}
	
	protected void loadMatrix(int location,ESTransform matrix){
	GLES30.glUniformMatrix4fv ( location, 1, false,
                                  matrix.getAsFloatBuffer() );
     TextureLoader.checkGLError("loadM "+location,location +" after LoadMatrix Error: ");
	}
	
	protected void loadVector(int location,Vector vec){
	GLES30.glUniform3f(location,vec.x,vec.y,vec.z);
	}
	
	protected int getUniformLocation(String name){
	return GLES20.glGetUniformLocation(id,name);
	}
	
	protected abstract void getAllUniformLocation();
	
	public void start(){
	GLES30.glUseProgram(id);
	}
	public void stop(){
	GLES30.glUseProgram(0);
	}
	
	public void cleanUp(){
	//nothing...🙂
	}
	
	protected void bindAttributes(int attr,String name){
	GLES20.glBindAttribLocation(id,attr,name);
	}
	
protected abstract void bindAttributes();

}
