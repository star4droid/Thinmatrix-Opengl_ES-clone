package com.my.opengl;
import android.opengl.GLES10;
import android.opengl.GLES20;
import android.opengl.GLES30;
import android.os.*;
import com.my.opengl.Models.RawModel;
import com.my.opengl.Models.TextureModel;
import android.content.ClipboardManager;
import android.content.ClipData;
import com.my.opengl.Entities.Entity;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import android.opengl.GLSurfaceView;
import com.my.opengl.Entities.Entity;

public class glRenderer extends android.opengl.GLSurfaceView  implements GLSurfaceView.Renderer {
	RendererT renderer;
	ModelTexture texture;
	Entity entity;
	TextureModel textureModel;
	
	public static android.widget.TextView activity;
	public glRenderer(android.content.Context ctx){
	super(ctx);
	setEGLConfigChooser(true);
	setEGLContextClientVersion(3);
	setRenderer(this);
	}
	public static android.widget.TextView debug=null;
	public RawModel model;
	staticShader shader;
	Loader loader= new Loader();
	int mWidth=300,mHeight=300;
	public float[] vertices=
	{
	-0.5f,0.5f,0f,
	-0.5f,-0.5f,0f,
	0.5f,-0.5f,0f,
	0.5f,0.5f,0f
	};
	int[] indices=
   {
	0,1,3,
	3,1,2
	};
	float[] textureCoords ={
	0,0,
	0,1,
	1,1,
	1,0
	};
	public void onSurfaceChanged ( GL10 gl, int width, int height )
   {
      mWidth = width;
      mHeight = height;
      //gl.glLoadIdentity();
   }
   
     public void onDrawFrame ( GL10 glUnused )
   {
   GLES30.glViewport ( 0, 0, mWidth, mHeight );
   TextureLoader.checkGLError("Render","after viewport Error: ");
   GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
	if((shader.id==0)|(true)){
	new Handler(Looper.getMainLooper()).post(new Runnable() {
				@Override
				public void run() {
   glRenderer.activity.setText("Errors \n"+staticShader.log);
   }
   });
	//GLES30.glClearColor(1,0,0,1);
	}
	TextureLoader.checkGLError("Render","Render before shader, Error: ");
	shader.start();
	TextureLoader.checkGLError("Render","Render draw Error: ");
   renderer.render(entity,shader);
   TextureLoader.checkGLError("Model Render","model Error: ");
   }
   
   public void onSurfaceCreated ( GL10 gl, EGLConfig config )
   {
	model= loader.loadToVao(vertices,textureCoords,indices);
	TextureLoader.checkGLError("Render","after loadToVao Error: ");
	TextureLoader.level=0;
	texture = new ModelTexture(loader.loadTexture(R.drawable.test,getContext(),gl));
	TextureLoader.checkGLError("Render","after texture Load Error: ");
	textureModel = new TextureModel(model,texture);
	
   //gl.glLoadIdentity();
   renderer = new RendererT();
   renderer.prepare();
   TextureLoader.checkGLError("Render","after prepare Error: ");
   shader = new staticShader(getContext());
   TextureLoader.checkGLError("Render","after shader con. Error: ");
   entity = new Entity(textureModel,new Vector(0,0,0),new Vector(0,0,0),1);
   if(shader.id==0){
   new Handler(Looper.getMainLooper()).post(new Runnable() {
				@Override
				public void run() {
   glRenderer.activity.setText("Errors \n"+staticShader.log);
   }
   });
   		//((ClipboardManager) activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", staticShader.log));
   } else {
   final RawModel r=model;
   new Handler(Looper.getMainLooper()).post(new Runnable() {
				@Override
				public void run() {
				glRenderer.activity.setText("id "+r.getVaoID());
				}
		});
   }
   
   }
}
