package com.my.opengl.ToolBox;
import com.my.opengl.ESTransform;
import com.my.opengl.Vector;
public class Maths {

	public static ESTransform createTransformationMatrix(Vector translation,Vector rotation,float scale){
	ESTransform matrix=new ESTransform();
	//Matrix.setIdentityM(matrix.get(),0);
	matrix.matrixLoadIdentity();
	matrix.translate(translation.x,translation.y,translation.z);
	matrix.rotate((float)Math.toRadians(rotation.x),1,0,0);
	matrix.rotate((float)Math.toRadians(rotation.y),0,1,0);
	matrix.rotate((float)Math.toRadians(rotation.z),0,0,1);
	matrix.scale(scale,scale,scale);
	return matrix;
	}

} 