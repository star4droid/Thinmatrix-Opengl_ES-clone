package com.my.opengl;
import android.opengl.GLES10;
import android.opengl.GLES20;
import android.opengl.GLES30;
import com.my.opengl.Models.RawModel;
import com.my.opengl.Models.TextureModel;
import com.my.opengl.Entities.Entity;
public class RendererT {
	public void prepare(){
	//GLES10.glClear(GLES10.GL_COLOR_BUFFER_BIT);
	//GLES10.glClearColor(1,0,0,0.6f);
	}
	
	public void render(Entity entity,staticShader shader){
	TextureModel textureModel=entity.getTextureModel();
	RawModel model= textureModel.getRawModel();
	TextureLoader.checkGLError("Render","Render Error: ");
	GLES20.glActiveTexture(GLES30.GL_TEXTURE0);
	TextureLoader.checkGLError("Render","Render0 Error: ");
	GLES30.glBindVertexArray(model.getVaoID());
	TextureLoader.checkGLError("Render","Render1 Error: ");
	GLES20.glEnableVertexAttribArray(0);
	TextureLoader.checkGLError("Render","Render2 Error: ");
	GLES20.glEnableVertexAttribArray(1);
	ESTransform transformation=com.my.opengl.ToolBox.Maths.createTransformationMatrix(entity.getPosition(),entity.getRotation(),entity.getScale());
	shader.loadTransformationMatrix(transformation);
	TextureLoader.checkGLError("Render","Render3 Error: ");
	//GLES20.glEnable(GLES20.GL_TEXTURE_2D);
	TextureLoader.checkGLError("Render","Render4 Error: ");
	GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,textureModel.getTexture().getID());
	TextureLoader.checkGLError("Render","Render6 Error: ");
	//GLES30.glVertexAttribPointer (0, 3,GLES30.GL_FLOAT, false,model.getVertexCount(),0 );
	//GLES10.glDrawArrays(GLES10.GL_TRIANGLES,0,model.getVertexCount());
	GLES30.glDrawElements ( GLES30.GL_TRIANGLES, model.getVertexCount(), GLES30.GL_UNSIGNED_INT, 0 );
	TextureLoader.checkGLError("Render","Render7 Error: ");
	GLES20.glDisableVertexAttribArray(0);
	TextureLoader.checkGLError("Render","Render8 Error: ");
	GLES20.glDisableVertexAttribArray(1);
	GLES30.glBindVertexArray(0);
	TextureLoader.checkGLError("Render","Render9 Error: ");
	}
}
