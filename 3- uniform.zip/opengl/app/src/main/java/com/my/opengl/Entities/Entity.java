package com.my.opengl.Entities;
import com.my.opengl.Models.TextureModel;
import com.my.opengl.Vector;
public class Entity {

	private TextureModel model;
	private Vector position;
	private Vector rotation;
	private float scale;
	public Entity(TextureModel texture,Vector trans, Vector rot,float sc){
	this.model=texture;
	this.position=trans;
	this.rotation=rot;
	this.scale=sc;
	}
	
	public void increasePosition(float x,float y,float z){
	this.position.x+=x;
	this.position.y+=y;
	this.position.z+=z;
	}
	
	public void increaseRotation(float x,float y,float z){
	this.rotation.x+=x;
	this.rotation.y+=y;
	this.rotation.z+=z;
	}
	
	public TextureModel getTextureModel(){
	return model;
	}
	
	public Vector getPosition(){
	return position;
	}
	
	public Vector getRotation(){
	return rotation;
	}
	
	public float getScale(){
	return scale;
	}
} 