package com.my.opengl;
import android.opengl.GLES30;

public class staticShader extends ShaderProgram {
	public static String log="Hello";
	int transformation=0;
	public staticShader(android.content.Context ctx){
	super("vertexShader.txt","fragmentShader.txt",ctx);
	//GLES30.glEnableVertexAttribArray ( VERTEX_POS_INDX );

      //GLES30.glVertexAttribPointer ( VERTEX_POS_INDX, VERTEX_POS_SIZE,GLES30.GL_FLOAT, false, VERTEX_STRIDE,0 );
	log="Nothing...";
	}
	
	@Override
	protected void bindAttributes(){
	super.bindAttributes(0,"position");
	super.bindAttributes(1,"textureCoords");
	}
	
	@Override
	protected void getAllUniformLocation(){
	transformation = super.getUniformLocation("transformation");
	TextureLoader.checkGLError("Render","failed to get transformation Error: ");
	}
	
	public void loadTransformationMatrix(ESTransform matrix){
	super.loadMatrix(transformation,matrix);
	}
	
}
