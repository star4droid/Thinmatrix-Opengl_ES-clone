package com.my.opengl;
import android.opengl.GLES10;
import android.opengl.GLES20;
import android.opengl.GLES30;

public class RendererT {
	public void prepare(){
	//GLES10.glClear(GLES10.GL_COLOR_BUFFER_BIT);
	//GLES10.glClearColor(0,1,0,1);
	}
	
	public void render(RawModel model){
	GLES30.glBindVertexArray(model.getVaoID());
	GLES20.glEnableVertexAttribArray(0);
	//GLES30.glVertexAttribPointer (0, 3,GLES30.GL_FLOAT, false,model.getVertexCount(),0 );
	//GLES10.glDrawArrays(GLES10.GL_TRIANGLES,0,model.getVertexCount());
	GLES30.glDrawElements ( GLES30.GL_TRIANGLES, model.getVertexCount(), GLES30.GL_UNSIGNED_INT, 0 );
	GLES20.glDisableVertexAttribArray(0);
	GLES30.glBindVertexArray(0);
	}
}
