package com.my.opengl;
import android.opengl.GLES30;

public class staticShader extends ShaderProgram {
	public static String log="Hello";

	public staticShader(android.content.Context ctx){
	super("vertexShader.txt","fragmentShader.txt",ctx);
	log="Nothing...";
	}
	
	@Override
	protected void bindAttributes(){
	super.bindAttributes(0,"position");
	}
}
