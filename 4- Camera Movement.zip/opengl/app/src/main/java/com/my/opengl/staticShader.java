package com.my.opengl;
import android.opengl.GLES30;
import com.my.opengl.ToolBox.Maths;
import com.my.opengl.ToolBox.ESTransform;

public class staticShader extends ShaderProgram {
	public static String log="Hello";
	int transformation;
	int projection;
	int viewMatrix;
	public staticShader(android.content.Context ctx){
	super("vertexShader.txt","fragmentShader.txt",ctx);
	log="Nothing...";
	}
	
	@Override
	protected void bindAttributes(){
	super.bindAttributes(0,"position");
	super.bindAttributes(1,"textureCoords");
	}
	
	@Override
	protected void getAllUniformLocation(){
	transformation = super.getUniformLocation("transformation");
	TextureLoader.checkGLError("Render","failed to get transformation Error: ");
	projection = super.getUniformLocation("projection");
	TextureLoader.checkGLError("Render","failed to get projection Error: ");
	viewMatrix = super.getUniformLocation("viewMatrix");
	TextureLoader.checkGLError("Render","failed to get viewMatrix Error: ");
	}
	
	public void loadViewMatrix(Camera camera){
	ESTransform matrix=Maths.createViewMatrix(camera);
	super.loadMatrix(viewMatrix,matrix);
	}
	
	public void loadTransformationMatrix(ESTransform matrix){
	super.loadMatrix(transformation,matrix);
	}
	
	public void loadProjectionMatrix(ESTransform matrix){
	super.loadMatrix(projection,matrix);
	}
}
