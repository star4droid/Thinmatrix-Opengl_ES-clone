package com.my.opengl;
import android.opengl.GLES10;
import android.opengl.GLES20;
import android.opengl.GLES30;
import android.os.*;
import com.my.opengl.Models.RawModel;
import com.my.opengl.Models.TextureModel;
import android.content.ClipboardManager;
import android.content.ClipData;
import com.my.opengl.Entities.Entity;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import android.opengl.GLSurfaceView;
import com.my.opengl.Entities.Entity;
import com.my.opengl.Entities.Light;
import com.my.opengl.ToolBox.Vector;

public class glRenderer extends android.opengl.GLSurfaceView  implements GLSurfaceView.Renderer {
	RendererT renderer;
	ModelTexture texture;
	Entity entity;
	Light light=new Light(new Vector(0,0,-1),new Vector(0,1,0));
	Camera camera = new Camera();
	TextureModel textureModel;
	
	
	public static android.widget.TextView activity;
	public glRenderer(android.content.Context ctx){
	super(ctx);
	setEGLConfigChooser(true);
	setEGLContextClientVersion(3);
	setRenderer(this);
	}
	public static android.widget.TextView debug=null;
	public RawModel model;
	staticShader shader;
	Loader loader= new Loader();
	int mWidth=300,mHeight=300;
	public void onSurfaceChanged ( GL10 gl, int width, int height )
   {
      mWidth = width;
      mHeight = height;
   }
   
     public void onDrawFrame ( GL10 glUnused )
   {
   GLES30.glViewport ( 0, 0, mWidth, mHeight );
   TextureLoader.checkGLError("Render","Render before shader, Error: ");
   shader.start();
   shader.loadLight(light);
   camera.move();
   shader.loadViewMatrix(camera);
   TextureLoader.checkGLError("Render","after viewport Error: ");
   GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
	if((shader.id==0)|(true)){
	new Handler(Looper.getMainLooper()).post(new Runnable() {
				@Override
				public void run() {
   glRenderer.activity.setText("Errors \n"+staticShader.log);
   }
   });
	//GLES30.glClearColor(1,0,0,1);
	}
	
	TextureLoader.checkGLError("Render","Render draw Error: ");
	entity.increaseRotation(0,30,30);
   renderer.render(entity,shader);
   TextureLoader.checkGLError("Model Render","model Error: ");
   }
   
   public void onSurfaceCreated ( GL10 gl, EGLConfig config )
   {
   shader = new staticShader(getContext());
   TextureLoader.checkGLError("Render","after shader con. Error: ");
	model= ObjLoader.loadObj(getContext(),"test.obj",loader);
	TextureLoader.checkGLError("Render","after loadToVao Error: ");
	TextureLoader.level=0;
	texture = new ModelTexture(loader.loadTexture(R.drawable.test,getContext()));
	TextureLoader.checkGLError("Render","after texture Load Error: ");
	textureModel = new TextureModel(model,texture);
	texture.setShineDampage(1);
	texture.setReflectivity(1);
   //gl.glLoadIdentity();
   //shader = new staticShader(getContext());
   //TextureLoader.checkGLError("Render","after shader con. Error: ");
   renderer = new RendererT(shader,mWidth,mHeight);
   renderer.prepare();
   TextureLoader.checkGLError("Render","after prepare Error: ");
   
   entity = new Entity(textureModel,new Vector(0,0,-5),new Vector(0,0,0),1);
   if(shader.id==0){
   new Handler(Looper.getMainLooper()).post(new Runnable() {
				@Override
				public void run() {
   glRenderer.activity.setText("Errors \n"+staticShader.log);
   }
   });
   		//((ClipboardManager) activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", staticShader.log));
   } else {
   final RawModel r=model;
   new Handler(Looper.getMainLooper()).post(new Runnable() {
				@Override
				public void run() {
				glRenderer.activity.setText("id "+r.getVaoID());
				}
		});
   }
   
   }
}
