package com.my.opengl;

public class ModelTexture {
    private int ID;
    private float shineDampage=1;
    private float reflectivity=0;
    
    public void setShineDampage(float shine){
    shineDampage=shine;
    }
    
    public void setReflectivity(float Reflectivity){
    reflectivity = Reflectivity;
    }
    public float getShineDampage(){
    return shineDampage;
    }
    
    public float getReflectivity(){
    return reflectivity;
    }
    
    public ModelTexture(int id){
    this.ID=id;
    }
    
    public int getID(){
    return this.ID;
    }
}
