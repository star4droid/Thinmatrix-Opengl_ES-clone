package com.my.opengl;
import android.content.Context;
import android.opengl.GLES30;
import android.opengl.GLES20;

public abstract class ShaderProgram {
	public int id;
	public ShaderProgram(String vertexShader,String fragmentShader,Context ctx){
	id=ESShader.loadProgramFromAsset(ctx,vertexShader,fragmentShader);
	bindAttributes();
}
	
	public void start(){
	GLES30.glUseProgram(id);
	}
	public void stop(){
	GLES30.glUseProgram(0);
	}
	
	public void cleanUp(){
	//nothing...🙂
	}
	
	protected void bindAttributes(int attr,String name){
	GLES20.glBindAttribLocation(id,attr,name);
	}
	
protected abstract void bindAttributes();
}
