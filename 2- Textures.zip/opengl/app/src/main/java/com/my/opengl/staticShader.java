package com.my.opengl;
import android.opengl.GLES30;

public class staticShader extends ShaderProgram {
	public static String log="Hello";
	final int VERTEX_POS_SIZE   = 3; // x, y and z
   final int VERTEX_COLOR_SIZE = 4; // r, g, b, and a

   final int VERTEX_POS_INDX   = 0;
   final int VERTEX_COLOR_INDX = 1;

   final int VERTEX_STRIDE     =  ( 4 * ( VERTEX_POS_SIZE +  VERTEX_COLOR_SIZE ) );
   
	public staticShader(android.content.Context ctx){
	super("vertexShader.txt","fragmentShader.txt",ctx);
	//GLES30.glEnableVertexAttribArray ( VERTEX_POS_INDX );

      //GLES30.glVertexAttribPointer ( VERTEX_POS_INDX, VERTEX_POS_SIZE,GLES30.GL_FLOAT, false, VERTEX_STRIDE,0 );
	log="Nothing...";
	}
	
	@Override
	protected void bindAttributes(){
	super.bindAttributes(0,"position");
	super.bindAttributes(1,"textureCoords");
	}
}
