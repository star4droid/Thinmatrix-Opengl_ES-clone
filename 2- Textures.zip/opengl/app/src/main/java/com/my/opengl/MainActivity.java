package com.my.opengl;

import android.app.*;
import android.os.*;
import android.view.*;
import android.util.Log;
import android.widget.TextView;
import android.opengl.GLSurfaceView;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //dont read this ==>
        Loader.toast=new Loader.Toast(){
          public int get(){
            int i=0;
            while(i==0){
              int[] VaoIDs=new int[1];
	android.opengl.GLES30.glGenVertexArrays(1,VaoIDs,0);
	i=VaoIDs[0];
            }
            return i;
          }
        };
        //requestWindowFeature(Window.FEATURE_NO_TITLE);
//javax.microedition.khronos.opengles.GL.createCapabilities();
//here u go
glRenderer.activity=(TextView)(findViewById(R.id.txt));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                        WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //glRenderer.debug=textview1;
        GLSurfaceView view = new glRenderer(MainActivity.this);
        Log.v("Start","Ok");
        //Loader loader= new Loader();
        /*glRenderer.model= loader.loadToVao(glRenderer.vertices);*/
		//glRenderer render = new glRenderer();
		//VAORenderer render = new VAORenderer(this);
        //view.setRenderer(render);
        ((ViewGroup)(findViewById(R.id.lin))).addView(view);
        
		//lin.addView(view);
    }
}
