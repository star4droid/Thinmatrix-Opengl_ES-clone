package com.my.opengl;

import android.app.AlarmManager;
import android.app.Application;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Process;
import android.util.Log;
import android.content.ClipData;
import android.content.ClipboardManager;
import com.my.opengl.DebugActivity;

public class MyApp
extends Application {
    private Thread.UncaughtExceptionHandler uncaughtExceptionHandler;

    public void onCreate() {
        this.uncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((Thread.UncaughtExceptionHandler)new Thread.UncaughtExceptionHandler(){

            public void uncaughtException(Thread thread, Throwable throwable) {
                Intent intent = new Intent(MyApp.this.getApplicationContext(), DebugActivity.class);
                intent.setFlags(32768);
                ((ClipboardManager) getSystemService(android.content.Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", Log.getStackTraceString((Throwable)throwable) ));
                intent.putExtra("error", Log.getStackTraceString((Throwable)throwable));
                PendingIntent pendingIntent = PendingIntent.getActivity((Context)MyApp.this.getApplicationContext(), (int)11111, (Intent)intent, (int)1073741824);
                ((AlarmManager)MyApp.this.getSystemService("alarm")).set(2, 1000L, pendingIntent);
                Process.killProcess((int)Process.myPid());
                System.exit((int)1);
                MyApp.this.uncaughtExceptionHandler.uncaughtException(thread, throwable);
            }
        });
        super.onCreate();
    }

}

