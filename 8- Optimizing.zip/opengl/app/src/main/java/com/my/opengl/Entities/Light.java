package com.my.opengl.Entities;

import com.my.opengl.ToolBox.Vector;

public class Light {
private Vector position;
private Vector colour;

public Light(Vector pos,Vector color){
this.colour = color;
this.position = pos;
}

public void setPosition(float x,float y,float z){
this.position = new Vector(x,y,z);
}

public void setColor(int r,int g,int b){
this.colour = new Vector(r,g,b);
}

public Vector getPosition(){
return position;
}

public Vector getColor(){
return colour;
}
} 