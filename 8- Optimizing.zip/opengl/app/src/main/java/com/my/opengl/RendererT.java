package com.my.opengl;
import android.opengl.GLES10;
import android.opengl.GLES20;
import android.opengl.GLES30;
import android.opengl.Matrix;
import com.my.opengl.Models.RawModel;
import com.my.opengl.Models.TextureModel;
import com.my.opengl.Entities.Entity;
import com.my.opengl.ToolBox.ESTransform;
import java.util.HashMap;
import java.util.ArrayList;

public class RendererT {
	private ESTransform projection= new ESTransform();
	private static final float FOV=70;
	private static final float Near=0.1f;
	private static final float Far=1000;
	private staticShader shader;
	public RendererT(staticShader shader,float mWidth,float mHeight){
	//GLES10.glClear(GLES10.GL_COLOR_BUFFER_BIT);
	//GLES10.glClearColor(1,0,0,0.6f);
	createProjectionMatrix(mWidth,mHeight);
	//shader.start();
	
	//shader.stop();
	this.shader=shader;
	}
	
	public void loadProjection(){
	shader.loadProjectionMatrix(projection);
	}
	
	public void prepare(){
	GLES10.glEnable(GLES30.GL_DEPTH_TEST);
	GLES10.glEnable(GLES30.GL_CULL_FACE);
	GLES10.glCullFace(GLES30.GL_BACK);
	}
	
	public void render(HashMap<TextureModel,ArrayList<Entity>> entities){
	//GLES10.glEnable(GLES30.GL_DEPTH_TEST);
	if(entities.size()==0) throw new RuntimeException("Size 0");
	for(TextureModel model:entities.keySet()){
	prepareTextureModel(model);
	ArrayList<Entity> batch = entities.get(model);
	for(Entity entity:batch){
	prepareInstance(entity);
	GLES30.glDrawElements ( GLES30.GL_TRIANGLES, model.getRawModel().getVertexCount(), GLES30.GL_UNSIGNED_INT, 0 );
	TextureLoader.checkGLError("Render","master Error: ");
	}
	unbindTextureModel();
	}
	}
	
	private void prepareTextureModel(TextureModel model){
	RawModel rawModel= model.getRawModel();
	ModelTexture texture=model.getTexture();
	GLES30.glBindVertexArray(rawModel.getVaoID());
	GLES20.glEnableVertexAttribArray(0);
	GLES20.glEnableVertexAttribArray(1);
	GLES20.glEnableVertexAttribArray(2);
	GLES20.glActiveTexture(GLES30.GL_TEXTURE0);
	GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,model.getTexture().getID());
	shader.loadShineVariables(texture.getShineDampage(),texture.getReflectivity());
	
	}
	
	private void unbindTextureModel(){
	GLES20.glDisableVertexAttribArray(0);
	GLES20.glDisableVertexAttribArray(2);
	GLES20.glDisableVertexAttribArray(1);
	GLES30.glBindVertexArray(0);
	}
	
	private void prepareInstance(Entity entity){
	ESTransform transformation=com.my.opengl.ToolBox.Maths.createTransformationMatrix(entity.getPosition(),entity.getRotation(),entity.getScale());
	shader.loadTransformationMatrix(transformation);
	}
	
	/*public void render(Entity entity,staticShader shader){
	GLES10.glEnable(GLES30.GL_CULL_FACE);
	GLES10.glCullFace(GLES30.GL_BACK);
	TextureModel textureModel=entity.getTextureModel();
	RawModel model= textureModel.getRawModel();
	ModelTexture texture=textureModel.getTexture();
	shader.loadShineVariables(texture.getShineDampage(),texture.getReflectivity());
	TextureLoader.checkGLError("Render","Render Error: ");
	GLES20.glActiveTexture(GLES30.GL_TEXTURE0);
	TextureLoader.checkGLError("Render","Render0 Error: ");
	GLES30.glBindVertexArray(model.getVaoID());
	TextureLoader.checkGLError("Render","Render1 Error: ");
	GLES20.glEnableVertexAttribArray(0);
	TextureLoader.checkGLError("Render","Render2 Error: ");
	GLES20.glEnableVertexAttribArray(1);
	GLES20.glEnableVertexAttribArray(2);
	
	ESTransform transformation=com.my.opengl.ToolBox.Maths.createTransformationMatrix(entity.getPosition(),entity.getRotation(),entity.getScale());
	shader.loadTransformationMatrix(transformation);
	TextureLoader.checkGLError("Render","Render3 Error: ");
	//GLES20.glEnable(GLES20.GL_TEXTURE_2D);
	TextureLoader.checkGLError("Render","Render4 Error: ");
	GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,textureModel.getTexture().getID());
	TextureLoader.checkGLError("Render","Render6 Error: ");
	//GLES30.glVertexAttribPointer (0, 3,GLES30.GL_FLOAT, false,model.getVertexCount(),0 );
	//GLES10.glDrawArrays(GLES10.GL_TRIANGLES,0,model.getVertexCount());
	GLES30.glDrawElements ( GLES30.GL_TRIANGLES, model.getVertexCount(), GLES30.GL_UNSIGNED_INT, 0 );
	TextureLoader.checkGLError("Render","Render7 Error: ");
	GLES20.glDisableVertexAttribArray(0);
	GLES20.glDisableVertexAttribArray(2);
	TextureLoader.checkGLError("Render","Render8 Error: ");
	GLES20.glDisableVertexAttribArray(1);
	GLES30.glBindVertexArray(0);
	TextureLoader.checkGLError("Render","Render9 Error: ");
	}*/
	
	private void createProjectionMatrix(float width,float height){
		float ratio = (float)width/(float)height;
      projection.matrixLoadIdentity();
      projection.perspective(FOV, ratio,Near,Far);
	}
}
