package com.my.opengl;
import java.util.HashMap;
import java.util.ArrayList;
import com.my.opengl.Entities.Light;
import com.my.opengl.Entities.Entity;
import com.my.opengl.Models.TextureModel;
import android.os.Looper;
import android.os.Handler;

public class MasterRenderer {

	private staticShader shader;
	private int Width,Height;
	private RendererT renderer;
	
	public MasterRenderer(float Width,float Height,android.content.Context ctx){
	shader= new staticShader(ctx);
	renderer = new RendererT(shader,Width,Height);
	}
	
	private HashMap<TextureModel,ArrayList<Entity>> entities = new HashMap<>();
	
	public void render(Light light,Camera camera){
	renderer.prepare();
	shader.start();
	renderer.loadProjection();
	shader.loadLight(light);
	shader.loadViewMatrix(camera);
	renderer.render(entities);
	shader.stop();
	entities.clear();
	}
	
	public void processEntity(Entity entity){
	TextureModel entityModel=entity.getTextureModel();
	ArrayList<Entity> batch = entities.get(entityModel);
	if(batch != null){
	batch.add(entity);
	} else {
	ArrayList<Entity> newBatch = new ArrayList<>();
	newBatch.add(entity);
	entities.put(entityModel,newBatch);
	}
	}
	
	public void cleanUp(){
	shader.cleanUp();
	}
} 