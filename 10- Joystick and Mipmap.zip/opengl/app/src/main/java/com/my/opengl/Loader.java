
package com.my.opengl;
import android.opengl.GLES30;
import android.opengl.GLES11;
import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import android.opengl.GLES11;
import android.opengl.GLES32;
//import javax.microedition.khronos.opengles.GL10;
//import android.content.Context;
import com.my.opengl.Models.RawModel;

import java.util.ArrayList;
public class Loader {
	private ArrayList<Integer> vaos = new ArrayList<>();
	private ArrayList<Integer> vbos = new ArrayList<>();
	private ArrayList<Integer> textures = new ArrayList<>();
	public static Toast toast = new Toast(){
	public int get(){return 0;}
	};
	public interface Toast {
	public int get();
	}
	
	public RawModel loadToVao(float[] positions,float[] textureCoords,float[] normals,int[] indices){
	int id=createVao();
	bindIndicesBuffer(indices);
	storeToAttributeList(0,3,positions);
	storeToAttributeList(1,2,textureCoords);
	storeToAttributeList(2,3,normals);
	//toast.go("after");
	unbindVao();
	return new RawModel(id,indices.length);
	}
	
	public void cleanUp(){
	for(int i:vaos){
	int[] id=new int[]{i};
	GLES30.glDeleteVertexArrays(1,id,0);
	}
	for(int i:vbos){
	int[] id= new int[]{i};
	GLES30.glDeleteBuffers(1,id,0);
	}
	for(int i:vbos){
	int[] id= new int[]{i};
	GLES20.glDeleteTextures(1,id,0);
	}
	}
	private int createVao(){
	int[] IDs=new int[1];
	//GLES30.glGenVertexArrays(1,VaoIDs,0);
	//int id=VaoIDs[0];
	//IntBuffer vaoIdBuffer = IntBuffer.allocate(1);
   //vaoIdBuffer.put(1);
   
  GLES30.glGenVertexArrays(1, IDs,0);
  //int id = vaoIdBuffer.get(0);
  //idk why, sometimes its return 0
int id=IDs[0];
  if(id==0) return createVao();
	vaos.add(id);
	GLES30.glBindVertexArray(id);
	return id;
	}
	private void storeToAttributeList(int number,int attrN,float[] data){
	int[] IDs= new int[1];
	//GLES30.glGenVertexArrays(1,VboIDs,0);
	//int id=VboIDs[0];
	//IntBuffer vboID = IntBuffer.allocate(1);
   //vboID.put(1);
  GLES30.glGenBuffers(1, IDs,0);
  int id=IDs[0];
 // int id = vboID.get(0);
  if(id==0){
  storeToAttributeList(number,attrN,data);
  return;
  }
	vbos.add(id);
	GLES11.glBindBuffer(GLES11.GL_ARRAY_BUFFER,id);
	FloatBuffer buffer = convertDataToFloatBuffer(data);
	GLES11.glBufferData(GLES30.GL_ARRAY_BUFFER,data.length*4,buffer,GLES30.GL_STATIC_DRAW);
	//GLES30.glEnableVertexAttribArray ( 0 );
	GLES20.glVertexAttribPointer(number,attrN,GLES20.GL_FLOAT,false,0,0);
	//GLES30.glVertexAttribPointer (number,3,GLES30.GL_FLOAT, false, 0, buffer );
	GLES11.glBindBuffer(GLES11.GL_ARRAY_BUFFER,0);
	}
	
	private void unbindVao(){
	GLES30.glBindVertexArray(0);
	}
	
	private void bindIndicesBuffer(int[] indices){
	//IntBuffer vboID = IntBuffer.allocate(1);
   //vboID.put(1);
   int[] IDs= new int[1];
  GLES30.glGenBuffers(1, IDs,0);
	int id = IDs[0];//vboID.get(0);
	if(id==0) { 
	bindIndicesBuffer(indices);
	return;
	}
	vbos.add(id);
	GLES11.glBindBuffer(GLES11.GL_ELEMENT_ARRAY_BUFFER,id);
	IntBuffer buffer = storeDataIntoBuffer(indices);
	GLES11.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER,indices.length*4,buffer,GLES30.GL_STATIC_DRAW);
	
	}
	
	private IntBuffer storeDataIntoBuffer(int[] data){
	ByteBuffer byteBuf = ByteBuffer.allocateDirect(data.length*4);
		byteBuf.order(ByteOrder.nativeOrder());
		IntBuffer buffer = byteBuf.asIntBuffer();
	buffer.put(data);
	buffer.position(0);
	//buffer.flip();
	return buffer;
	}
	
	public int loadTexture(int rid,android.content.Context c){
	int id= TextureLoader.createTexture(c,rid);
	textures.add(id);
	/*GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D);
	GLES11.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES30.GL_TEXTURE_MIN_FILTER,GLES11.GL_LINEAR_MIPMAP_LINEAR);
	GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D,GLES32.GL_MAX_TEXTURE_LOD_BIAS,-1);*/
	return id;
	}
	
	private FloatBuffer convertDataToFloatBuffer(float[] data){
	ByteBuffer byteBuf = ByteBuffer.allocateDirect(data.length*4);
		byteBuf.order(ByteOrder.nativeOrder());
		FloatBuffer buffer = byteBuf.asFloatBuffer();
	buffer.put(data);
	buffer.position(0);
	//buffer.flip();
	return buffer;
	}
	
}
