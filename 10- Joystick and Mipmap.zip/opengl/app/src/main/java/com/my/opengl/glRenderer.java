package com.my.opengl;
//import android.opengl.GLES10;
//import android.opengl.GLES20;
import android.opengl.GLES30;
import com.my.opengl.Models.RawModel;
import com.my.opengl.Models.TextureModel;
//import com.my.opengl.Entities.Entity;
import javax.microedition.khronos.egl.EGLConfig;
import com.my.opengl.Shaders.staticShader;
import javax.microedition.khronos.opengles.GL10;
import android.opengl.GLSurfaceView;
import com.my.opengl.Entities.Entity;
import com.my.opengl.Entities.Light;
import com.my.opengl.ToolBox.Vector;
import Terrains.Terrain;

public class glRenderer extends android.opengl.GLSurfaceView  implements GLSurfaceView.Renderer {
	ModelTexture texture;
	ModelTexture TreeTexture;
	Entity entity;
	Entity entity2;
	Entity Tree;
	Terrain terrain;
	Terrain terrain2;
	MasterRenderer master;
	Light light=new Light(new Vector(0,0,-1),new Vector(0,1,0.0f));
	Camera camera = new Camera();
	TextureModel textureModel;
	TextureModel textureModel2;
	TextureModel TreetextureModel;
	
	public static android.widget.TextView activity;
	public glRenderer(android.content.Context ctx){
	super(ctx);
	setEGLConfigChooser(true);
	setEGLContextClientVersion(3);
	setRenderer(this);
	}
	public static android.widget.TextView debug=null;
	public RawModel model;
	public RawModel TreeModel;
	staticShader shader;
	Loader loader= new Loader();
	int mWidth=300,mHeight=300;
	public void onSurfaceChanged ( GL10 gl, int width, int height )
   {
      mWidth = width;
      mHeight = height;
   }
   
     public void onDrawFrame ( GL10 glUnused )
   {
   GLES30.glViewport ( 0, 0, mWidth, mHeight );
   TextureLoader.checkGLError("Render","Render before master, Error: ");
   GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
	entity.increaseRotation(0,30,30);
	Tree.increaseRotation(0,30,30);
	//entity.increasePosition(0,0,0.035f);
	light.getPosition().z+=0.01f;
	camera.move();
   master.processEntity(entity);
   master.processTerrain(terrain);
   //failed to load, idk why
   master.processEntity(Tree);
   master.processTerrain(terrain2);
   //master.processEntity(entity2);
   master.render(light,camera);
   TextureLoader.checkGLError("Model Render","model Error: ");
   }
   
   public void onSurfaceCreated ( GL10 gl, EGLConfig config )
   {
   MainActivity.x=0;
   MainActivity.y=0;
   MainActivity.z=0;
   camera.setPostion(0,3,0);
   master = new MasterRenderer(mWidth,mHeight,getContext());
	model= ObjLoader.loadObj(getContext(),"test.obj",loader);
	TreeModel= ObjLoader.loadObj(getContext(),"tree.obj",loader);
	TextureLoader.checkGLError("Render","after loadToVao Error: ");
	TextureLoader.level=0;
	texture = new ModelTexture(loader.loadTexture(R.drawable.test,getContext()));
	
	TreeTexture = new ModelTexture(loader.loadTexture(R.drawable.white,getContext()));
	terrain = new Terrain(0,-1,loader,new ModelTexture(loader.loadTexture(R.drawable.test,getContext())));
	terrain2 = new Terrain(1,-5,loader,new ModelTexture(loader.loadTexture(R.drawable.test,getContext())));
	TextureLoader.checkGLError("Render","after texture Load Error: ");
	textureModel = new TextureModel(model,texture);
	texture.setShineDampage(10);
	texture.setReflectivity(1);
   TreeTexture.setShineDampage(0);
	TreeTexture.setReflectivity(0);
   textureModel2 = new TextureModel(model,texture);
   TextureModel TreeTextureModel = new TextureModel(TreeModel,TreeTexture);
	textureModel2.setDensity(40);
	//Entity(translation,rotation,scale)
	Tree = new Entity(TreeTextureModel,new Vector(-2,0,0),new Vector(0,0,0),new Vector(1,1,1));
   entity = new Entity(textureModel,new Vector(0,3,-5),new Vector(0,0,0),1);
   entity2 = new Entity(textureModel2,new Vector(0,3,-10),new Vector(0,0,0),new Vector(1,1,1));
   
   }
}
