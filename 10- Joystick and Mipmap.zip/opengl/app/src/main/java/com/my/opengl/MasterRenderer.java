package com.my.opengl;
import java.util.HashMap;
import java.util.ArrayList;
import com.my.opengl.Entities.Light;
import com.my.opengl.Entities.Entity;
import com.my.opengl.Models.TextureModel;
import android.os.Looper;
import android.os.Handler;
import com.my.opengl.Shaders.staticShader;
import com.my.opengl.Shaders.TerrainShader;
import android.opengl.GLES30;
import android.opengl.GLES20;
import com.my.opengl.ToolBox.ESTransform;
import android.opengl.GLES10;
import Terrains.TerrainRenderer;
import Terrains.Terrain;

public class MasterRenderer {
	
	private static final float FOV=70;
	private static final float Near=0.1f;
	private static final float Far=1000;
	
	private float RED=0.0f,GREEN=0.0f,BLUE=0.0f;
	
	private staticShader shader;
	private int Width,Height;
	private RendererT renderer;
	private TerrainRenderer Trenderer;
	private TerrainShader Tshader;
	private ESTransform projection= new ESTransform();
	
	public MasterRenderer(float Width,float Height,android.content.Context ctx){
	GLES10.glEnable(GLES30.GL_DEPTH_TEST);
	GLES10.glEnable(GLES30.GL_CULL_FACE);
	GLES10.glCullFace(GLES30.GL_BACK);
	shader= new staticShader(ctx);
	Tshader = new TerrainShader(ctx);
	createProjectionMatrix(Width,Height);
	Trenderer = new TerrainRenderer(Tshader,projection);
	renderer = new RendererT(shader,Width,Height,projection);
	}
	
	public void prepare(){
	GLES20.glClearColor(RED,GREEN,BLUE,1);
	}
	
	private HashMap<TextureModel,ArrayList<Entity>> entities = new HashMap<>();
	private ArrayList<Terrain> terrains = new ArrayList<>();
	
	public void render(Light light,Camera camera){
	prepare();
	shader.loadSkyColour(RED,GREEN,BLUE);
	shader.start();
	shader.loadLight(light);
	shader.loadViewMatrix(camera);
	shader.loadProjectionMatrix(projection);
	renderer.render(entities);
	shader.stop();
	entities.clear();
	
	//terrain
	Tshader.start();
	Tshader.loadLight(light);
	Tshader.loadViewMatrix(camera);
	Tshader.loadProjectionMatrix(projection);
	Trenderer.render(terrains);
	Tshader.stop();
	terrains.clear();
	}
	
	public void processTerrain(Terrain terrain){
	terrains.add(terrain);
	}
	
	public void processEntity(Entity entity){
	TextureModel entityModel=entity.getTextureModel();
	ArrayList<Entity> batch = entities.get(entityModel);
	if(batch != null){
	batch.add(entity);
	} else {
	ArrayList<Entity> newBatch = new ArrayList<>();
	newBatch.add(entity);
	entities.put(entityModel,newBatch);
	}
	}
	
	private void createProjectionMatrix(float width,float height){
		float ratio = (float)width/(float)height;
      projection.matrixLoadIdentity();
      projection.projection(width,height,FOV,Far,Near);
	}
	
	public void cleanUp(){
	shader.cleanUp();
	Tshader.cleanUp();
	}
} 