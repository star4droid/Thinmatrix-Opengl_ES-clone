package Terrains;
import com.my.opengl.Shaders.TerrainShader;
import com.my.opengl.ToolBox.ESTransform;
import java.util.ArrayList;
import com.my.opengl.ToolBox.Vector;
import android.opengl.GLES20;
import android.opengl.GLES30;
import com.my.opengl.Models.RawModel;
import com.my.opengl.ModelTexture;

public  class  TerrainRenderer {

	private TerrainShader shader;
	
	public TerrainRenderer(TerrainShader shader,ESTransform matrix){
	this.shader = shader;
	shader.start();
	shader.loadProjectionMatrix(matrix);
	shader.stop();
	
	}
	
	public void render(ArrayList<Terrain> terrains){
	for(Terrain terrain:terrains){
	prepareTerrain(terrain);
	loadModelMatrix(terrain);
	GLES30.glDrawElements ( GLES30.GL_TRIANGLES, terrain.getModel().getVertexCount(), GLES30.GL_UNSIGNED_INT, 0 );
	unbindTextureModel();
	}
	}
	
	private void prepareTerrain(Terrain terrain){
	RawModel rawModel= terrain.getModel();
	ModelTexture texture= terrain.getTexture();
	GLES30.glBindVertexArray(rawModel.getVaoID());
	GLES20.glEnableVertexAttribArray(0);
	GLES20.glEnableVertexAttribArray(1);
	GLES20.glEnableVertexAttribArray(2);
	GLES20.glActiveTexture(GLES30.GL_TEXTURE0);
	GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,texture.getID());
	shader.loadShineVariables(texture.getShineDampage(),texture.getReflectivity());
	
	}
	
	private void unbindTextureModel(){
	GLES20.glDisableVertexAttribArray(0);
	GLES20.glDisableVertexAttribArray(2);
	GLES20.glDisableVertexAttribArray(1);
	GLES30.glBindVertexArray(0);
	}
	
	private void loadModelMatrix(Terrain terrain){
	ESTransform transformation=com.my.opengl.ToolBox.Maths.createTransformationMatrix(new Vector(terrain.getX(),0,terrain.getZ()),new Vector(0,0,0),new Vector(1,1,1));
	shader.loadTransformationMatrix(transformation);
	}
}
