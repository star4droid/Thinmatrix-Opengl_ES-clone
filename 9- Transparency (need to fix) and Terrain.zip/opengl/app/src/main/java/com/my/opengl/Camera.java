package com.my.opengl; 
import com.my.opengl.ToolBox.Vector;

public class Camera {
private Vector position = new Vector(0,0,0);
//private Vector rotation = new Vector(0,0,0);

private float pitch=0,yaw=0,roll=0;

public Camera(){

}

public void move(){
//pitch+=33.0f;
position.z+=0.035f;
}

public Vector getPosition(){
return position;
}

public float getPitch(){
return pitch;
}

public float getYaw(){
return yaw;
}

public float getRoll(){
return roll;
}

} 